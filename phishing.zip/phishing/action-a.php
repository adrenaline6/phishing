<?php
$emails = json_decode(file_get_contents('./emails.json'), true);
$emailsA = json_decode(file_get_contents('./emails-a.js'), true);
$exclude_emails = preg_split('#[\r\n\s\t]+#', file_get_contents('exclude-emails.json'));

foreach ($emailsA as $addr) {
  $name = $emails[$addr];
  echo 'Sending ', $name, ' ', $addr, '...', PHP_EOL;
  if (in_array($addr, $exclude_emails) || !str_ends_with($addr, '@dfcorp.com')) {
    echo 'excluded', PHP_EOL;
    continue;
  }
  system('php ke-hoach-cds.php "' . $addr . '" "' . $name . '"');
  sleep(15);
}